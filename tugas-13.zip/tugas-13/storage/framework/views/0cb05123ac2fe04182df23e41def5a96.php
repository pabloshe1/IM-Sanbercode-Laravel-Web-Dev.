<?php $__env->startSection('content'); ?>
<div class="card">
  <div class="card-body">
    <h5 class="card-title fw-semibold mb-2">Dashboard</h5>
    <h1 class="display-6 fw-bold">Selamat Datang <?php echo e($first_name); ?> <?php echo e($last_name); ?></h1>
    <h3 class="fw-semibold text-muted">Terima kasih telah bergabung di Sanberbook. Social Media kita bersama!</h3>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/pablo/IM Sanbercode Laravel Web Dev/tugas-12/resources/views/welcome.blade.php ENDPATH**/ ?>